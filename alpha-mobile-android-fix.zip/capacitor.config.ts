import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.infdev.voxelengine',
  appName: 'Infdev Mobile Voxel Engine',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    hostname: 'scenic-beaker-7nzsc.firebaseapp.com',
    allowNavigation: [
      'scenic-beaker-7nzsc.firebaseapp.com',
      '*.firebaseapp.com',
      'accounts.google.com',
      'accounts.youtube.com',
      '*.google.com',
      '*.googleusercontent.com',
      '*.gstatic.com',
      'apis.google.com',
      '*.googleapis.com',
      '*.firebaseio.com',
      '*.firebase.com'
    ]
  }
};

export default config;
